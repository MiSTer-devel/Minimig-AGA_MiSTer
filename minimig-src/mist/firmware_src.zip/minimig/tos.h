#ifndef TOS_H
#define TOS_H

void tos_upload();
void tos_show_state();

#endif
