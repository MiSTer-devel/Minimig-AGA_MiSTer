#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <arpa/inet.h>  // for htons/htonl

typedef struct {
  unsigned int next;       // $fa0004
  unsigned int init;       // $fa0008
  unsigned int run;        // $fa000c
  unsigned short time;     // $fa0010
  unsigned short date;     // $fa0012
  unsigned int size;       // $fa0014
  unsigned char name[12];  // $fa0018
} __attribute__ ((packed)) app_header_t;

int main(int argc, char **argv) {
  printf("mkcart - tos cartridge creator\n");

  if(argc < 3) {
    printf("Usage: mkupg cartridge.img <tos program>.prg ...\n");
    return -1;
  }
  
  FILE *outf;
  outf = fopen(argv[1], "wb");
  if(!outf) {
    printf("Unable to open %s\n", argv[1]);
    return -1;
  }

  // write cartridge header
  unsigned int magic = htonl(0xabcdef42);
  fwrite(&magic, 1, sizeof(unsigned int), outf);
  int written = 4;

  int i;
  for(i=2;i<argc;i++) {
    app_header_t app;

    printf("processing %s\n", argv[i]);

    int size;
    FILE *inf;

    inf = fopen(argv[i], "rb");
    if(!inf) {
      printf("Unable to open %s\n", argv[i]);
      return -1;
    }

    // check file size
    fseek(inf, 0, SEEK_END);
    size = ftell(inf);
    fseek(inf, 0, SEEK_SET);

    // write application header
    memset(&app, 0, sizeof(app_header_t));
    app.next = 0;
    app.init = 0;
    app.run  = htonl(0xfa0000 + written + 0x14 + 12);
    app.time = 0;
    app.date = 0;
    app.size = htonl(size);
    strcpy(app.name, "S.PRG");
    fwrite(&app, 1, sizeof(app_header_t), outf);
    written += sizeof(app_header_t);
    
    // write application
    unsigned char *bin = malloc(size);
    if(fread(bin, 1, size, inf) != size) {
      printf("Read error on %s\n", argv[i]);
      return -1;
    }
    fclose(inf);

    fwrite(bin, 1, size, outf);
    written += size;
  }

  if(written > 128*1024) 
    printf("ERROR: cartridge size exceeds 128k!!!\n");
    
  while(written < 128*1024) {
    fputc(0, outf);
    written++;
  }

  fclose(outf);



  return 0;
}
