/*

 */

#ifndef MIST_H
#define MIST_H

// FPGA spi cmommands
#define MIST_INVALID      0x00

// memory interface
#define MIST_SET_ADDRESS  0x01
#define MIST_WRITE_MEMORY 0x02
#define MIST_READ_MEMORY  0x03
#define MIST_SET_CONTROL  0x04
#define MIST_GET_DMASTATE 0x05   // reads state of dma and floppy controller
#define MIST_ACK_DMA      0x06   // acknowledges a dma command

// control bits (all control bits have unknown state after core startup)
#define MIST_CONTROL_CPU_RESET    0x01
#define MIST_CONTROL_8MB          0x02
#define MIST_CONTROL_14MB         0x04
#define MIST_CONTROL_xxMB         0x08
#define MIST_CONTROL_FDC_WR_PROT  0x10
#define MIST_CONTROL_CPU68000     0x00
#define MIST_CONTROL_CPU68010     0x20
#define MIST_CONTROL_CPU68020     0x60

#endif // MIST_H
