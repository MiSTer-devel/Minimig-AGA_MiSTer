/* boot_print.h */
/* 2012, rok.krajnc@gmail.com */

#ifndef __BOOT_PRINT_H__
#define __BOOT_PRINT_H__


extern unsigned short bcurx;
extern unsigned short bcury;

void BootPrintEx(char * str);


#endif // __BOOT_PRINT_H__

