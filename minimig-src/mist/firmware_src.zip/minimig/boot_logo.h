/* boot_logo.h */
/* 2012, rok.krajnc@gmail.com */

#ifndef __BOOT_LOGO_H__
#define __BOOT_LOGO_H__


void draw_boot_logo();


#endif // __BOOT_LOGO_H__
