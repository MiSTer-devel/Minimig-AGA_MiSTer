
two layer PCB FR-4/1.55mm/0.18um
 
HASL or ENIG

hole diameters final

soldermasks on both sides

top layer overlay

