/* $Id: devcommands.h,v 4.3 1999/03/28 22:31:42 lcs Exp $ */

/*
     AHI - Hardware independent audio subsystem
     Copyright (C) 1997-1999 Martin Blom <martin@blom.org>
     
     This library is free software; you can redistribute it and/or
     modify it under the terms of the GNU Library General Public
     License as published by the Free Software Foundation; either
     version 2 of the License, or (at your option) any later version.
     
     This library is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
     Library General Public License for more details.
     
     You should have received a copy of the GNU Library General Public
     License along with this library; if not, write to the
     Free Software Foundation, Inc., 59 Temple Place - Suite 330, Cambridge,
     MA 02139, USA.
*/

#ifndef _DEVCOMMANDS_H_
#define _DEVCOMMANDS_H_

#include "ahi_def.h"

void
PerformIO ( struct AHIRequest *ioreq,
            struct AHIBase *AHIBase );

struct Node *
FindNode ( struct List *list,
           struct Node *node );

void
FeedReaders ( struct AHIDevUnit *iounit,
              struct AHIBase *AHIBase );

void
RethinkPlayers ( struct AHIDevUnit *iounit,
                 struct AHIBase *AHIBase );

void 
UpdateSilentPlayers ( struct AHIDevUnit *iounit,
                      struct AHIBase *AHIBase );

#endif /* _DEVCOMMANDS_H_ */
